#include "GameStatsDisplay.h"
//realised that i need to seperate this into lives and score, asking if posible to do in 1?


//GameStatsDisplay::GameStatsDisplay(GameObject* pOwner, Player* pObservedPlayerComp, int startValue)
//	: Component(pOwner)
//{
//	pObservedPlayerComp->
//		m_pTextComponent = pOwner->GetComponent<TextComponent>();
//		UpdateDisplay(startValue);
//}
//
//GameStatsDisplay::~GameStatsDisplay()
//{
//
//}
//
//void GameStatsDisplay::OnNotify(int stat)
//{
//	UpdateDisplay(stat);
//
//}
//
//void GameStatsDisplay::UpdateDisplay(int stat)
//{
//	if (m_pTextComponent)
//	{
//		m_pTextComponent->SetText(std::to_string(stat));
//	}
//	else
//	{
//		std::cout << "a GameStatsDisplay does not have a pTextComponent to find" << std::endl;
//	}
//}


