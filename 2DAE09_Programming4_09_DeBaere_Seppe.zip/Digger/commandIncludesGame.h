#ifndef commandIncludeGame
#include "DieCommand.h"
#include "ScoreCommand.h"
#endif // !commandIncludeGame
