#pragma once

struct Vector3i
{
	int x, y, z;
};

struct Vector3f
{
	float x, y, z;
};

struct Vector2f
{
	float x, y;
};

